# Changelog

## Unreleased

## 1.5.0

- Add `convert_bulk()` helper for converting a list of amounts at a single rate

## 1.4.1

- Fix default rounding precision (1 dp) that dropped cents on every conversion

## 1.4.0

- Round conversions to cents

## 1.3.2

- Initial release
