# Changelog

## Unreleased

## 1.4.1

- Fix conversions rounding to 1 decimal place instead of the nearest cent

## 1.4.0

- Round conversions to cents

## 1.3.2

- Initial release
