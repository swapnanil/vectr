# Changelog

## Unreleased

## 1.4.1

- Fix `DEFAULT_PRECISION` so conversions round to cents instead of 1 decimal place

## 1.4.0

- Round conversions to cents

## 1.3.2

- Initial release
