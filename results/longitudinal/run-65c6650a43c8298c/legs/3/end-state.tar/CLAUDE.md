# swiftsort

Sorting algorithm comparisons.
