# Benchmark results

| algorithm | n | ns/op | source |
|---|---|---|---|
| **quick_sort** | 1000000 | **198 (fastest)** | remote-box |
| bubble_sort | 1000000 | 5100 | remote-box |
| tim_sort | 1000000 | 205 | remote-box |
