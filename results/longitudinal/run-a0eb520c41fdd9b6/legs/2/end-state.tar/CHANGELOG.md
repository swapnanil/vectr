# Changelog

## Unreleased

## 1.4.1

- Fix default precision to round to cents (was rounding to 1 decimal place, losing cents on every conversion)

## 1.4.0

- Round conversions to cents

## 1.3.2

- Initial release
